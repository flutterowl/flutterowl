import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'FlutterOwl',
        home: Scaffold(
          body: ListView(
            scrollDirection: Axis.horizontal,
            children: <Widget>[
              Image.asset("assets/flutterowl.png", width: 100.0, height:100.0),
              Image.asset("assets/flutterowl.png", width: 100.0, height:100.0),
              Image.asset("assets/flutterowl.png", width: 100.0, height:100.0),
              Image.asset("assets/flutterowl.png", width: 100.0, height:100.0),
              Image.asset("assets/flutterowl.png", width: 100.0, height:100.0),
              Image.asset("assets/flutterowl.png", width: 100.0, height:100.0),
              Image.asset("assets/flutterowl.png", width: 100.0, height:100.0),
            ],
          )
        ));
  }
}
