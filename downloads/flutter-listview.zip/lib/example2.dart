import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FlutterOwl',
      home: Scaffold(
        appBar: AppBar(
          title: Text("7 wonders"),
        ),
        body: ListView(
          children: <Widget>[
            ListTile(
                leading: Image.network(
                    "https://d36tnp772eyphs.cloudfront.net/blogs/1/2018/02/Taj-Mahal.jpg"),
                title: Text("Taj Mahal"),
                subtitle: Text("India")),
            ListTile(
                leading: Image.network(
                    "https://d36tnp772eyphs.cloudfront.net/blogs/1/2018/02/Christ-the-Redeemer.jpg"),
                title: Text("Christ the Redeemer"),
                subtitle: Text("Brazil")),
            ListTile(
                leading: Image.network(
                    "https://d36tnp772eyphs.cloudfront.net/blogs/1/2016/03/petra-jordan9.jpg"),
                title: Text("Petra"),
                subtitle: Text("Jordan")),
            ListTile(
                leading: Image.network(
                    "https://d36tnp772eyphs.cloudfront.net/blogs/1/2018/02/Great-Wall-of-China-view.jpg"),
                title: Text("The Great Wall of China"),
                subtitle: Text("China")),
            ListTile(
                leading: Image.network(
                    "https://d36tnp772eyphs.cloudfront.net/blogs/1/2018/02/View-of-the-Colosseum.jpg"),
                title: Text("The Colosseum"),
                subtitle: Text("Rome")),
            ListTile(
                leading: Image.network(
                    "https://d36tnp772eyphs.cloudfront.net/blogs/1/2018/02/Machu-Picchu-around-sunset.jpg"),
                title: Text("Machu Picchu"),
                subtitle: Text("Peru")),
            ListTile(
                leading: Image.network(
                    "https://d36tnp772eyphs.cloudfront.net/blogs/1/2018/02/Chichen-Itza-at-night.jpg"),
                title: Text("Chichén Itzá"),
                subtitle: Text("Mexico")),
          ],
        ),
      ),
    );
  }
}
