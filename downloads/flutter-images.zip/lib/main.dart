import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'FlutterOwl',
        home: Scaffold(
          body: Center(
            child: Image.asset("assets/flutterowl.png", height: 150.0, width: 150.0)
            // child: Image.network("https://flutterowl.com/flutterowl.png", height: 150.0, width: 150.0)
          ),
        ));
  }
}
