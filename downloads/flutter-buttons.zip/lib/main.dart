import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FlutterOwl',
      home: Scaffold(
          appBar: AppBar(
            title: Text("Flutter Button"),
          ),
          body: Center(
              child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              RaisedButton(
                child: Text("RaisedButton"),
                onPressed: () {},
              ),
              FlatButton(
                child: Text("FlatButton"),
                onPressed: () {},
              ),
              OutlineButton(
                child: Text("OutlineButton"),
                onPressed: () {},
              ),
              IconButton(
                icon: Icon(Icons.favorite),
                onPressed: () {},
              ),
            ],
          ))),
    );
  }
}
