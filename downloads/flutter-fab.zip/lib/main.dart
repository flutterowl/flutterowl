import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(home: MyApp()));

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("FlutterOwl"),
        backgroundColor: Colors.lightBlue[900],
      ),
      body: Center(child: Text("Floating Action Button")),
      // FAB with Icon
      
      // floatingActionButton: FloatingActionButton(
      //   backgroundColor: Colors.orange,
      //   child: Icon(Icons.search),
      //   onPressed: () {},
      // ),

      // floatingActionButton: FloatingActionButton.extended(
      //   backgroundColor: Colors.orange,
      //   icon: Icon(Icons.search),
      //   label: Text("Search"), 
      //   onPressed: () {},
      // ),

    );
  }
}
