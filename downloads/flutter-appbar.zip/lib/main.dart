import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(home: MyApp()));

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("FlutterOwl"),
        centerTitle: true,
        backgroundColor: Colors.lightBlue[900],
        leading: Icon(Icons.menu),
        actions: <Widget>[
          Icon(Icons.notifications),
          Icon(Icons.more_vert)
        ],
      ),
    );
  }
}
