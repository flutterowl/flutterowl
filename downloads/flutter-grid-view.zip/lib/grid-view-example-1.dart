import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FlutterOwl',
      home: Scaffold(
        appBar: AppBar(
          title: Text("Grid View"),
        ),
        body:
        GridView.count(
          padding: EdgeInsets.all(8.0),
          crossAxisCount: 3,
          mainAxisSpacing: 4.0,
          crossAxisSpacing: 4.0,
          children: <Widget>[
            Container( child: Image.network("https://placeimg.com/640/480/any", fit: BoxFit.cover)),
            Container( child: Image.network("https://placeimg.com/640/480/any", fit: BoxFit.cover)),
            Container( child: Image.network("https://placeimg.com/640/480/any", fit: BoxFit.cover)),
            Container( child: Image.network("https://placeimg.com/640/480/any", fit: BoxFit.cover)),
            Container( child: Image.network("https://placeimg.com/640/480/any", fit: BoxFit.cover)),
            Container( child: Image.network("https://placeimg.com/640/480/any", fit: BoxFit.cover)),
          ],
        ),
      ),
    );
  }
}
