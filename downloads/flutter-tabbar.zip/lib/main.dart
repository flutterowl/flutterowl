import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(home: MyApp()));

class MyApp extends StatelessWidget {
  int _selectedTabIndex = 0;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: 4,
        child: Scaffold(
            appBar: AppBar(
              title: Text("FlutterOwl"),
              backgroundColor: Colors.lightBlue[900],
              bottom: TabBar(tabs: <Widget>[
                Tab(icon: Icon(Icons.photo_camera)),
                Tab(text: "Chats"),
                Tab(text: "Status"),
                Tab(text: "Calls")
              ]),
            ),
            body: TabBarView(
              children: <Widget>[
                Center(child: Text("camera")),
                Center(child: Text("Chats")),
                Center(child: Text("Status")),
                Center(child: Text("Calls")),
              ],
            )));
  }
}
